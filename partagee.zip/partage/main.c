#include<stdio.h>
#include<stdlib.h>
#include"SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "hero.h"
#include  "background.h"

int main()
{
Hero *H1;
Hero *H2;
background *Back;
SDL_Surface *screen;
SDL_Init(SDL_INIT_VIDEO); 
screen=SDL_SetVideoMode(1280,604,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
    if(screen==NULL)
    {
        printf("Unable to set video mode : %s",SDL_GetError());
        return 1;
    }
/*loadHero(&H1,"../source/sprite1.png");
loadHero(&H2,"../source/sprite2.png");
initialiser_hero(&H1,1);
initialiser_hero(&H2,2);
blithero(&H1,&screen);
blithero(&H2,&screen);*/
/*loadBackground(Back);
initialiser_Background(Back);
blitbackground(Back,screen);
blitbackground2(Back,screen);*/

return 0;
}

