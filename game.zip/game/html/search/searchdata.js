var indexSectionsWithContent =
{
  0: "abfhm",
  1: "abh",
  2: "fm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files"
};

