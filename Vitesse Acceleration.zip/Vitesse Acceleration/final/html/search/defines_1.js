var searchData=
[
  ['fps',['FPS',['../text_8h.html#ac92ca5ab87034a348decad7ee8d4bd1b',1,'text.h']]]
];
