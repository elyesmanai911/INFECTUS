var searchData=
[
  ['back_5fimg',['back_Img',['../structBackground.html#a13df092f4ec6aebf0364559926479761',1,'Background']]],
  ['back_5fimg2',['back_Img2',['../structBackground.html#a43f21e56f1aa47666ffb4afb34d71cf7',1,'Background']]],
  ['back_5fpos',['back_Pos',['../structBackground.html#a4921effe7d9612c8a1870bee947e4441',1,'Background']]],
  ['background',['Background',['../structBackground.html',1,'']]],
  ['background_2ec',['background.c',['../background_8c.html',1,'']]],
  ['background_2eh',['background.h',['../background_8h.html',1,'']]],
  ['blitbackground',['blitBackground',['../background_8c.html#acd20976661c4bf621c809bf465f59f68',1,'blitBackground(Background *Back, SDL_Surface *screen):&#160;background.c'],['../background_8h.html#acd20976661c4bf621c809bf465f59f68',1,'blitBackground(Background *Back, SDL_Surface *screen):&#160;background.c']]]
];
