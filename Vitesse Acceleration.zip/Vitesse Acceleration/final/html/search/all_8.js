var searchData=
[
  ['screen_5fh',['SCREEN_H',['../text_8h.html#a27cddfd509d28b4b2b0b44c093fac090',1,'text.h']]],
  ['screen_5fw',['SCREEN_W',['../text_8h.html#a9b6bc9242882d1e758e06ed751a2e8ec',1,'text.h']]]
];
