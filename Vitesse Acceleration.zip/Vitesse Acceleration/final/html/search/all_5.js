var searchData=
[
  ['loadbackground',['loadBackground',['../background_8c.html#a7690baf8498d427ca7dbb6ff0f06b142',1,'loadBackground(Background *Back):&#160;background.c'],['../background_8h.html#a7690baf8498d427ca7dbb6ff0f06b142',1,'loadBackground(Background *Back):&#160;background.c']]],
  ['loadfont',['loadFont',['../text_8c.html#a6f50df17af941d4d1aff8d62c336edca',1,'loadFont(TTF_Font **police):&#160;text.c'],['../text_8h.html#a6f50df17af941d4d1aff8d62c336edca',1,'loadFont(TTF_Font **police):&#160;text.c']]],
  ['loadvoitureimages',['loadVoitureImages',['../voiture_8c.html#a20fdd4e4c29a45446e170697fdcd8df3',1,'loadVoitureImages(Voiture *A):&#160;voiture.c'],['../voiture_8h.html#a20fdd4e4c29a45446e170697fdcd8df3',1,'loadVoitureImages(Voiture *A):&#160;voiture.c']]]
];
