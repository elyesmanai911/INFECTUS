var searchData=
[
  ['afficher_5ftext',['Afficher_Text',['../text_8c.html#a307b7655043a42402d751a3da90ff1d0',1,'Afficher_Text(TTF_Font *police, Text *T, SDL_Surface *screen, Voiture V, Background Back, Time *time, Uint32 dt):&#160;text.c'],['../text_8h.html#a307b7655043a42402d751a3da90ff1d0',1,'Afficher_Text(TTF_Font *police, Text *T, SDL_Surface *screen, Voiture V, Background Back, Time *time, Uint32 dt):&#160;text.c']]]
];
