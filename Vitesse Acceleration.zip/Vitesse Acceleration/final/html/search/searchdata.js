var indexSectionsWithContent =
{
  0: "abdfilmpstv",
  1: "btv",
  2: "bmtv",
  3: "abfilm",
  4: "abdfimptv",
  5: "afs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Macros"
};

