var searchData=
[
  ['blitbackground',['blitBackground',['../background_8c.html#acd20976661c4bf621c809bf465f59f68',1,'blitBackground(Background *Back, SDL_Surface *screen):&#160;background.c'],['../background_8h.html#acd20976661c4bf621c809bf465f59f68',1,'blitBackground(Background *Back, SDL_Surface *screen):&#160;background.c']]]
];
