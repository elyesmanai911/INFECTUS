var searchData=
[
  ['accelx',['ACCELX',['../text_8h.html#a91023e7c9b297a2cf1ef0728903a4308',1,'text.h']]],
  ['accely',['ACCELY',['../text_8h.html#a7434bdf859f83feeae7473fdf8841c18',1,'text.h']]]
];
