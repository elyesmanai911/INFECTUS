var searchData=
[
  ['font',['font',['../structTime.html#a870d34231ad11f87e284a0fd74b22f33',1,'Time']]]
];
