var searchData=
[
  ['freebackground',['freeBackground',['../background_8c.html#a04645de4c3c73cae976c1ceb1fe06548',1,'freeBackground(Background *Back):&#160;background.c'],['../background_8h.html#a04645de4c3c73cae976c1ceb1fe06548',1,'freeBackground(Background *Back):&#160;background.c']]],
  ['freefont',['freeFont',['../text_8c.html#aed94d72c6d43ac78f60f25e0d622d3bd',1,'freeFont(TTF_Font **police):&#160;text.c'],['../text_8h.html#aed94d72c6d43ac78f60f25e0d622d3bd',1,'freeFont(TTF_Font **police):&#160;text.c']]],
  ['freevoiture',['freeVoiture',['../voiture_8c.html#a4d5d4a48e7800b5768acf4b5b5ba6cf9',1,'freeVoiture(Voiture *A):&#160;voiture.c'],['../voiture_8h.html#a4d5d4a48e7800b5768acf4b5b5ba6cf9',1,'freeVoiture(Voiture *A):&#160;voiture.c']]]
];
