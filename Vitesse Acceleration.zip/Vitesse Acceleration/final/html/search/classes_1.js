var searchData=
[
  ['text',['Text',['../structText.html',1,'']]],
  ['time',['Time',['../structTime.html',1,'']]]
];
