#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
/**
* @struct Background
* @brief struct for backround
*/
typedef struct 
{
 SDL_Surface *img;/* !<Surface.*/
 SDL_Surface *img1;/* !<Surface.*/
 SDL_Surface *img2;/* !<Surface.*/

}enigme;
enigme init_enigme(enigme  e);
 void blit(SDL_Surface *screen,SDL_Surface *e);

