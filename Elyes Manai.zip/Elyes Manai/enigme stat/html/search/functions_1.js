var searchData=
[
  ['init_5fenigme',['init_enigme',['../enig_8c.html#a9623cbc0b41b4dabfda723b1fcb69d8c',1,'init_enigme(enigme e):&#160;enig.c'],['../enig_8h.html#a9623cbc0b41b4dabfda723b1fcb69d8c',1,'init_enigme(enigme e):&#160;enig.c']]]
];
