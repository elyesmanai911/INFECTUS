#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "enig.h"
/**
* @brief To initialize the enigma e.
* @param e the enigma
* @return the enigma
*/
enigme init_enigme(enigme  e)
{
	
	e.img=IMG_Load("1.jpg");
	e.img1=IMG_Load("00.jpg");
	e.img2=IMG_Load("11.jpg");
	return e;

}
/**
* @brief To blit an image 
* @param b the background
* @param the image we' re aiming to blit
* @return Nothing
*/
 void blit(SDL_Surface *screen,SDL_Surface *e)
{
	SDL_BlitSurface(e, NULL, screen,NULL) ;

}

/*void resolution (enigme *e )
{
	SDL_Event event ;
	int run=1;
	SDL_PollEvent(&event);
	switch(event.type)
	{
		  case SDL_QUIT:
 
                run = 0;
				break ;

       case SDL_KEYDOWN : 
            switch( event.key.keysym.sym )
                {
			  case  SDLK_a: 
			  e->img=IMG_Load("11.jpg");
			   break ;
			   case  SDLK_z :
			   e->img=IMG_Load("11.jpg");
			   break;
			   case SDLK_e: 
			   e->img=IMG_Load("00.jpg");
			   break;
			    }
       break ;

                 
	}

}*/
 

 
