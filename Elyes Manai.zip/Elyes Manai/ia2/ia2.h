#ifndef IA2_H_
#define IA2_H_
#include<stdio.h>
#include<stdlib.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>
typedef struct
{
SDL_Surface *backg;
SDL_Surface *but1;
SDL_Surface *but2;
SDL_Surface *but3;
SDL_Rect pos_but11;
SDL_Rect pos_but12;
SDL_Rect pos_but13;
SDL_Rect pos_but21;
SDL_Rect pos_but22;
SDL_Rect pos_but23;
SDL_Rect  pos_but31;
SDL_Rect  pos_but32;
SDL_Rect pos_but33;
}enigme;
enigme init_e(enigme e,SDL_Surface *screen);
void ia(int t[3][3]);
void init_t(int t[3][3]);
void blit_ord(int t[3][3],SDL_Surface *screen,enigme e);
void blit_utl(int t[3][3],int a,int b,enigme e,SDL_Surface *screen);
int gagnant(int t[3][3]);
int gameover(int t[3][3]);
#endif
