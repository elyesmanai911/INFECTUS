#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "ia2.h"


int main(void)
{
int t[3][3];

int a,b;
int i=0;
int j=0;

SDL_Surface *screen;
SDL_Surface *texte;
SDL_Rect posecran;
SDL_Rect positiontexte;
enigme e;
int done=1;
// Declaration


TTF_Font *police = NULL;
SDL_Color couleur= {255,150, 0};

/* Chargement de la police */
    TTF_Init();
    police = TTF_OpenFont("CHICORY_.TTF",15);


/* Écriture du texte dans la SDL_Surface texte en mode Blended (optimal) */
    
texte = TTF_RenderText_Blended(police,"Playing...",couleur);
        
        positiontexte.x = 200;
        positiontexte.y = 189;


if(SDL_Init(SDL_INIT_VIDEO)!=0)
    {
        printf("Unable to inizialize SDL: %s \n",SDL_GetError());
        return 1;
    }


// Creation screen

screen=SDL_SetVideoMode(720,721,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
    if(screen==NULL)
    {
        printf("Unable to set video mode : %s",SDL_GetError());
        return 1;
    }
  for(i=0;i<3;i++)
{for(j=0;j<3;j++)
{t[i][j]=0;
}}

  e=init_e(e,screen);
blit_ord(t,screen,e);

SDL_Flip(screen);
////////////////////////////// 

SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);



while(done)

{


SDL_Event event;

while(SDL_PollEvent(&event))
{

switch(event.type)
  {


case SDL_QUIT:
  {done=0;
   break;}


case SDL_MOUSEBUTTONDOWN:
            {
                a=event.button.x;
                b=event.button.y ;
		blit_utl(t,a,b,e,screen);
}
ia(t);
blit_ord(t,screen,e);
if(gagnant(t)==-1)
{
	texte = TTF_RenderText_Blended(police,"Vous avez gagné",couleur);
      SDL_BlitSurface(texte, NULL,screen,&positiontexte); /* texte */



}
else if(gagnant(t)==1)
{
	texte = TTF_RenderText_Blended(police,"Machine gagne",couleur);
      SDL_BlitSurface(texte, NULL,screen,&positiontexte); /* texte */

}
else if(gameover(t)==1)
{
	texte = TTF_RenderText_Blended(police,"Egalité",couleur);
      SDL_BlitSurface(texte, NULL,screen,&positiontexte); /* texte */

}

SDL_Flip(screen);

}
}

}

// Liberation memoire



SDL_Quit();
SDL_Delay(10);

return 0;

}
