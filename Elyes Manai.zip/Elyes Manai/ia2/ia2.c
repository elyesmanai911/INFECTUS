#include<stdio.h>
#include<stdlib.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>
#include"ia2.h"
enigme init_e(enigme e,SDL_Surface *screen)
{
  e.but1=IMG_Load("but2.png");
  e.but2=IMG_Load("but1.png");
  e.but3=IMG_Load("but3.png");
  e.backg=SDL_LoadBMP("enigmestatbackfinal1.bmp");
 

  e.pos_but11.x=203.2;
  e.pos_but11.y=344.5;

  e.pos_but21.x=203.2;
  e.pos_but21.y=421;

  e.pos_but31.x=203.2;
  e.pos_but31.y=497.5;
///////
  e.pos_but12.x=335.4;
  e.pos_but12.y=344.5;

  e.pos_but22.x=335.4;
  e.pos_but22.y=421;

  e.pos_but32.x=335.4;
  e.pos_but32.y=497.5;
//////////
  e.pos_but13.x=471.4;
  e.pos_but13.y=344.5;



  e.pos_but23.x=471.4;
  e.pos_but23.y=421;



  e.pos_but33.x=471.4;
  e.pos_but33.y=497.5;


  e.pos_but11.w=e.but1->w;
  e.pos_but11.h=e.but1->h;
  e.pos_but12.w=e.but1->w;
  e.pos_but12.h=e.but1->h;
  e.pos_but13.w=e.but1->w;
  e.pos_but13.h=e.but1->h;
  e.pos_but21.w=e.but1->w;
  e.pos_but21.h=e.but1->h;
  e.pos_but22.w=e.but1->w;
  e.pos_but22.h=e.but1->h;
  e.pos_but23.w=e.but1->w;
  e.pos_but23.h=e.but1->h;
  e.pos_but31.w=e.but1->w;
  e.pos_but31.h=e.but1->h;
  e.pos_but32.w=e.but1->w;
  e.pos_but32.h=e.but1->h;
  e.pos_but33.w=e.but1->w;
  e.pos_but33.h=e.but1->h;
//////////////////////////////////////////////////
  SDL_BlitSurface(e.backg,NULL,screen,NULL);

return (e);
}


void init_t(int t[3][3])
{
int i,j;
for(i=0;i<3;i++)
{for(j=0;j<3;j++)
{t[i][j]=0;}}
}


/*void ia(int t[3][3])
{
int i,j;
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
k=t[i][j];
switch(k)
{
 case 0:
{

}
break;
case 2:
{
}
case -2:
{
}
break;
 /*if(((t[i][j]+t[i+1][j]=)&&(t[i+2][j]==0))
	t[i+2][j]=1;
	
else if((t[i][j]==-1)&&(t[i][j]==t[i][j+1])&&(t[i][j+2]==0))
	t[i][j+2]=2;
else if((t[i][j]==-1)&&(t[i+2][j+2]==0))
	t[i+2][j+2]=2;
else if((t[i][j]==-1)&&(t[i][j]==t[i+2][j])&&(t[i+1][j]==0))
	t[i+1][j]=1;
else if((t[i][j]==-1)&&(t[i][j]==t[i][j+2])&&(t[i][j+1]==0))
	t[i][j+1]=1;
else if((t[i][j]==-1)&&(t[i][j]==t[i+2][j+2])&&(t[i+1][j+1]==0))
	t[i+1][j+1]=1;
}
}

}*/
void ia(int t[3][3])
{

int i,j,e,k,h,l,n,test=0;
k=t[0][0]+t[1][1]+t[2][2];
e=t[0][2]+t[1][1]+t[2][0];
if(k==2)
{
	for(l=0;l<3;l++)
	{
	 if((t[l][l]==0)&&test==0)
	 {
		t[l][l]=1;
		test=1;
	 }
	}
}
else if(e==2)
{
	for(l=0;l<3;l++)
	{
	 if((t[l][l-2]==0)&&test==0)
	 {	
		t[l][l-2]=1;
		test=1;
	 }
	}
}


for(i=0;i<3;i++)
{
if(test==0)
{
h=t[i][0]+t[i][1]+t[i][2];
j=t[0][i]+t[1][i]+t[2][i];
if(h==2)
{
for(l=0;l<3;l++)
{
if((t[i][l]==0)&&test==0)
{
	t[i][l]=1;
	test=1;
}
}
}
else if(j==2)
{
for(l=0;l<3;l++)
{
if((t[l][i]==0)&&test==0)
{
	t[l][i]=1;
	test=1;	
}
}
}
else if(h==-2)
{
for(l=0;l<3;l++)
{
if((t[i][l]==0)&&test==0)
{
	t[i][l]=1;
	test=1;
}
}
}
else if(j==-2)
{
for(l=0;l<3;l++)
{
if((t[l][i]==0)&&test==0)
{
	t[l][i]=1;
	test=1;	
}
}
}
}
else 
	break;

}
 if(k==-2)
{
	for(l=0;l<3;l++)
	{
	 if((t[l][l]==0)&&test==0)
	 {
		t[l][l]=1;
		test=1;
	 }
	}
}
else if(e==-2)
{
	for(l=0;l<3;l++)
	{
	 if((t[l][l-2]==0)&&test==0)
	 {	
		t[l][l-2]=1;
		test=1;
	 }
	}
}
else if(test==0)
{
 for(l=0;l<3;l++)

{
for(n=0;n<3;n++)
{
 if ((t[l][n]==0)&&test==0)
	{
	  t[l][n]=1;
	  test=1;
	  break;
	}
}
if(test==1)
   break;
}
}
}
















void blit_utl(int t[3][3],int a,int b,enigme e,SDL_Surface *screen)
{
 if((a>e.pos_but11.x)&&(a<e.pos_but11.x+e.pos_but11.w)&&(b>e.pos_but11.y)&&(b<e.pos_but11.y+e.pos_but11.h))
{
 t[0][0]=-1;
  // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but11);
}
else if((a>e.pos_but12.x)&&(a<e.pos_but12.x+e.pos_but12.w)&&(b>e.pos_but12.y)&&(b<e.pos_but12.y+e.pos_but12.h))
{
 t[0][1]=-1;
    //SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but12);
}
 else if((a>e.pos_but13.x)&&(a<e.pos_but13.x+e.pos_but13.w)&&(b>e.pos_but13.y)&&(b<e.pos_but13.y+e.pos_but13.h))
{
 t[0][2]=-1;
   // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but13);
}
else if((a>e.pos_but21.x)&&(a<e.pos_but21.x+e.pos_but21.w)&&(b>e.pos_but21.y)&&(b<e.pos_but21.y+e.pos_but21.h))
{
 t[1][0]=-1;
   // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but21);
}
else if((a>e.pos_but22.x)&&(a<e.pos_but22.x+e.pos_but22.w)&&(b>e.pos_but22.y)&&(b<e.pos_but22.y+e.pos_but22.h))
{
 t[1][1]=-1;
   // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but22);
}
 else if((a>e.pos_but23.x)&&(a<e.pos_but23.x+e.pos_but23.w)&&(b>e.pos_but23.y)&&(b<e.pos_but23.y+e.pos_but23.h))
{
 t[1][2]=-1;
   // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but23);
}
else if((a>e.pos_but31.x)&&(a<e.pos_but31.x+e.pos_but31.w)&&(b>e.pos_but31.y)&&(b<e.pos_but31.y+e.pos_but31.h))
{
 t[2][0]=-1;
   // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but31);
}
else if((a>e.pos_but32.x)&&(a<e.pos_but32.x+e.pos_but32.w)&&(b>e.pos_but32.y)&&(b<e.pos_but32.y+e.pos_but32.h))
{
 t[2][1]=-1;
  // SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but32);
}
else if((a>e.pos_but33.x)&&(a<e.pos_but33.x+e.pos_but33.w)&&(b>e.pos_but33.y)&&(b<e.pos_but33.y+e.pos_but33.h))
{
   t[2][2]=-1;
    //SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but33);
}
}













/*void blit_ord(int t[3][3],SDL_Surface *screen,enigme e)
{
int i,j;
for(i=0;i<3;i++)
{for(j=0;j<3;j++)
{if(t[i][j]=1)
  { switch(i)
    {case 0:
{
      switch(j)
	{ 
           case 0:
		   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but11);
           break;
           case 1:
                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but12);
	   break;
           case 2:
                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but13);
           break;
        }
}
break;
     case 1:
{
      switch(j)
	{ 
           case 0:
SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but21);
           break;
           case 1:
SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but22);
	   break;
           case 2:
  SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but23);
           break;
        }
}
break;	
     case 2:
{
      switch(j)
	{ 
           case 0:
   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but31);
           break;
           case 1:
   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but32);
	   break;
           case 2:
   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but33);
           break;
        }       
}
	break;
}
}
}
}
}*/

void blit_ord(int t[3][3],SDL_Surface *screen,enigme e)
{

if(t[0][0]==1)                        SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but11); 
else if(t[0][0]==-1)                        SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but11); 

else if(t[0][0]==0)                        SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but11); 



 if(t[0][1]==1)	              SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but12);
else if(t[0][1]==-1)	              SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but12);
else if(t[0][1]==0)	              SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but12);

 if(t[0][2]==1)                   SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but13);
 else if(t[0][2]==-1)                   SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but13);
else  if(t[0][2]==0)                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but13);

 if(t[1][0]==1)                   SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but21);

 else if(t[1][0]==-1)                   SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but21);
else  if(t[1][0]==0)                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but21);

 if(t[1][1]==1)                   SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but22);
 else if(t[1][1]==-1)                   SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but22);
 else if(t[1][1]==0)                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but22);
 

 if(t[1][2]==1)                   SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but23);
 else if(t[1][2]==-1)                   SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but23);
else  if(t[1][2]==0)                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but23);


 if(t[2][0]==1)                   SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but31);
else  if(t[2][0]==-1)                   SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but31);
else if(t[2][0]==0)                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but31);


 if(t[2][1]==1)                   SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but32);
 else if(t[2][1]==-1)                   SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but32);
else if(t[2][1]==0)                   SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but32);

 if(t[2][2]==1) 		      SDL_BlitSurface(e.but1,NULL,screen,&e.pos_but33);
 else if(t[2][2]==-1) 		      SDL_BlitSurface(e.but2,NULL,screen,&e.pos_but33);
 else if(t[2][2]==0) 		      SDL_BlitSurface(e.but3,NULL,screen,&e.pos_but33);

}

int gagnant(int t[3][3])
{

int i,j,e,k,h,l;
k=t[0][0]+t[1][1]+t[2][2];
e=t[0][2]+t[1][1]+t[2][0];
if(k==-3)

	
                return -1;

else if(k==3)

	return 1;
else if(e==-3)
{


                return -1;
}
else if(e==3)
	return 1;


for(i=0;i<3;i++)
{
h=t[i][0]+t[i][1]+t[i][2];
j=t[0][i]+t[1][i]+t[2][i];
for(l=0;l<3;l++)
{
if((h==-3)||(j==-3))
	return -1;
else if((h==3)||(j==3))
	return 1;
}

}
return 0;
}
int gameover(int t[3][3])
{
int i,j,k=0;
for(i=0;i<3;i++)
{for(j=0;j<3;j++)
{if ((t[i][j]!=0)&&(k!=9))
	k++;

}
}
if(k==9)
	return 1;
else 
	return 0;
}
//void test
/*void blit(enigme e,SDL_Surface *screen){
  SDL_BlitSurface(H.personnage,&H.poshero,screen,&H.posimage);
}
int input(int a,SDL_Event *event,int *done)
{


	SDL_PollEvent(event);
	switch(event.type)
	{
		  case SDL_QUIT:
			        *done= 0 ;

				break ;

       case SDL_KEYDOWN :
            switch( event.key.keysym.sym )
                {
			  case  SDLK_1:
			  a= 1;
			   break ;
			   case  SDLK_2 :
			   a= 2;
			   break;
			   case SDLK_3:
			   a=3 ;
			   break;
			  case  SDLK_4:
			  a= 4;
			   break ;
			   case  SDLK_5 :
			   a= 5;
			   break;
			   case SDLK_6:
			   a=6 ;
			   break;
			  case  SDLK_7:
			  a= 7;
			   break ;
			   case  SDLK_8:
			   a= 8;
			   break;
			   case SDLK_9:
			   a=9;
			   break;

			    }
       break ;


	}
  return a ;
}*/
/*void ()
{
srand(time(NULL));
alea=1+rand()%x;
}*/
