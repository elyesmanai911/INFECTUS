#include <stdio.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
int main(void)
{
SDL_Surface*screen;
SDL_Surface*image;
SDL_Surface*guard;
SDL_Rect posecran;
SDL_Rect posguard;
SDL_Event event;
int running=1;

while(running)
{
		while(SDL_PollEvent(&event))
		{

			if(event.type==SDL_QUIT || (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE))
		{
				running = 0;
		}

}
if (SDL_Init(SDL_INIT_VIDEO)!=0)
{
printf("Unable to initialise sdl %s\n",SDL_GetError());
return 1;
}
screen=SDL_SetVideoMode(600,400,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
if (screen==NULL)
{
printf("Unable to set screen %s\n",SDL_GetError());
return 1;
}
image=IMG_Load("back.jpg");
if (image==NULL)
{
printf("Unable to set bmp image %s\n",SDL_GetError());
return 1;
}
guard=IMG_Load("guard.png");
if (guard==NULL)
{
printf("unable to load object image %s \n",SDL_GetError());
return 1;
}
posecran.x=0;
posecran.y=0;
posecran.w=image->w;
posecran.h=image->h;
posguard.x=370;
posguard.y=225;
SDL_BlitSurface(image,NULL,screen,&posecran);
SDL_BlitSurface(guard,NULL,screen,&posguard);
SDL_Flip(screen);
SDL_FreeSurface(image);
SDL_FreeSurface(guard);
}
SDL_Quit();
return 0;

}

