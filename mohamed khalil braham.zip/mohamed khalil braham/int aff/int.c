#include <stdio.h>
#include  <stdlib.h>
#include  <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "int.h"
SDL_Surface*Init(SDL_Surface*guard,SDL_Surface*image)
{
	SDL_Rect posecran;
	SDL_Rect posguard;
	guard=IMG_Load("guard.png");
	if(guard==NULL)
	{
		printf("Cannot load image %s",SDL_GetError());
	}
	else
	{
		posecran.x=0;
		posecran.y=0;
		posecran.w=image->w;
		posecran.h=image->h;
		posguard.x=370;
		posguard.y=225;
	}
	return guard;
}
void aff_guard(SDL_Surface*guard,SDL_Rect* screen,SDL_Surface*image)
{
	SDL_Rect posecran;
	SDL_Rect posguard;
	image=IMG_Load("back.jpg");
	SDL_BlitSurface(image,NULL,screen,&posecran);
	SDL_BlitSurface(guard,NULL,screen,&posguard);	
	SDL_Flip(screen);
	SDL_FreeSurface(image);
	SDL_FreeSurface(guard);
}
