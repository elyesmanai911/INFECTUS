#pragma once
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
SDL_Surface*Init(SDL_Surface*obj,SDL_Surface*image);
void aff_obj(SDL_Surface*obj,SDL_Rect*screen,SDL_Surface*image);
